#!/usr/bin/env python3


from brain_games.scripts.funct_progression import progression


def main():
    progression()


if __name__ == '__main__':
    main()
