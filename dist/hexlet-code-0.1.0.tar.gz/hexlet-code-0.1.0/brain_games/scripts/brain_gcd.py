#!/usr/bin/env python3


from brain_games.scripts.funct_gcd import gcd_f


def main():
    gcd_f()


if __name__ == '__main__':
    main()
